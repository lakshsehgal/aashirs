import React from 'react'
import Dashboard from './Dashboard.jsx'

export default function App() {
  return <Dashboard />
}
